// Curated list of popular skills and interests (can be expanded)
export const SKILLS = [
  "JavaScript", "Python", "Java", "C++", "React", "Node.js", "Spring Boot", "HTML", "CSS", "MongoDB", "SQL", "TypeScript", "Django", "Flask", "Angular", "Vue.js", "Express.js", "Kotlin", "Swift", "Go", "Rust", "PHP", "Ruby", "C#", "Machine Learning", "Data Science", "DevOps", "AWS", "Azure", "Docker", "Kubernetes", "Git", "Linux", "Android", "iOS", "UI/UX", "Figma", "Photoshop", "Illustrator"
];

export const INTERESTS = [
  "Web Development", "Mobile Development", "AI", "Machine Learning", "Data Science", "Cloud Computing", "Cybersecurity", "Open Source", "Competitive Programming", "Blockchain", "Game Development", "UI/UX Design", "Startups", "FinTech", "EdTech", "HealthTech", "Robotics", "IoT", "AR/VR", "Quantum Computing", "Photography", "Music", "Travel", "Sports", "Reading", "Writing", "Art", "Design"
];
